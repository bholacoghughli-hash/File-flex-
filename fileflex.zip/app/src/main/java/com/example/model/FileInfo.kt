package com.example.model

import android.net.Uri

data class FileInfo(
    val uri: Uri,
    val name: String,
    val extension: String,
    val sizeBytes: Long,
    val mimeType: String,
    val category: FileCategory,
    val imageWidth: Int = 0,
    val imageHeight: Int = 0,
    val mediaDurationMs: Long = 0L,
    val isTextPreviewable: Boolean = false,
    val textSample: String? = null
) {
    val formattedSize: String
        get() {
            if (sizeBytes <= 0) return "0 B"
            val units = arrayOf("B", "KB", "MB", "GB")
            var size = sizeBytes.toDouble()
            var unitIndex = 0
            while (size >= 1024 && unitIndex < units.size - 1) {
                size /= 1024
                unitIndex++
            }
            return String.format(java.util.Locale.US, "%.1f %s", size, units[unitIndex])
        }

    val dimensionsString: String?
        get() = if (imageWidth > 0 && imageHeight > 0) "${imageWidth} × ${imageHeight}" else null

    val durationString: String?
        get() = if (mediaDurationMs > 0) {
            val totalSec = mediaDurationMs / 1000
            val min = totalSec / 60
            val sec = totalSec % 60
            String.format(java.util.Locale.US, "%02d:%02d", min, sec)
        } else null
}
