package com.example.engine

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object ArchiveEngine {

    fun createZipFromFiles(
        files: List<File>,
        outputZipFile: File,
        onProgress: (Float) -> Unit
    ): File {
        if (files.isEmpty()) throw IllegalArgumentException("No files provided for ZIP packaging")

        val zos = ZipOutputStream(FileOutputStream(outputZipFile))
        val buffer = ByteArray(8192)
        val totalFiles = files.size

        files.forEachIndexed { index, file ->
            if (file.exists() && file.isFile) {
                val entry = ZipEntry(file.name)
                zos.putNextEntry(entry)
                FileInputStream(file).use { fis ->
                    var len: Int
                    while (fis.read(buffer).also { len = it } > 0) {
                        zos.write(buffer, 0, len)
                    }
                }
                zos.closeEntry()
            }
            onProgress((index + 1).toFloat() / totalFiles)
        }

        zos.finish()
        zos.close()
        return outputZipFile
    }

    fun createZipFromUris(
        context: Context,
        uris: List<Pair<Uri, String>>,
        outputZipFile: File,
        onProgress: (Float) -> Unit
    ): File {
        if (uris.isEmpty()) throw IllegalArgumentException("No URIs provided for ZIP packaging")

        val zos = ZipOutputStream(FileOutputStream(outputZipFile))
        val buffer = ByteArray(8192)
        val total = uris.size

        uris.forEachIndexed { index, (uri, name) ->
            val entry = ZipEntry(name)
            zos.putNextEntry(entry)
            context.contentResolver.openInputStream(uri)?.use { stream ->
                var len: Int
                while (stream.read(buffer).also { len = it } > 0) {
                    zos.write(buffer, 0, len)
                }
            }
            zos.closeEntry()
            onProgress((index + 1).toFloat() / total)
        }

        zos.finish()
        zos.close()
        return outputZipFile
    }
}
