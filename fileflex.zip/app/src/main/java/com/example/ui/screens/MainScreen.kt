package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DynamicFeed
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.outlined.DynamicFeed
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.localization.StringsProvider
import com.example.model.JobStatus
import com.example.viewmodel.MainViewModel

enum class MainTab {
    CONVERT,
    BATCH,
    HISTORY,
    SETTINGS
}

@Composable
fun MainScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val configuration = LocalConfiguration.current
    val isTablet = configuration.screenWidthDp >= 600

    var currentTab by remember { mutableStateOf(MainTab.CONVERT) }
    val snackbarHostState = remember { SnackbarHostState() }

    // State Collection
    val language by viewModel.appLanguage.collectAsState()
    val selectedFileInfo by viewModel.selectedFileInfo.collectAsState()
    val availableFormats by viewModel.availableOutputFormats.collectAsState()
    val selectedTarget by viewModel.selectedTargetFormat.collectAsState()
    val conversionOptions by viewModel.conversionOptions.collectAsState()
    val currentJob by viewModel.currentJob.collectAsState()

    val batchQueue by viewModel.batchQueue.collectAsState()
    val isBatchProcessing by viewModel.isBatchProcessing.collectAsState()

    val filteredHistory by viewModel.filteredHistory.collectAsState()
    val searchQuery by viewModel.historySearchQuery.collectAsState()
    val categoryFilter by viewModel.historyCategoryFilter.collectAsState()

    val themeMode by viewModel.themeMode.collectAsState()
    val cacheSize by viewModel.cacheSizeBytes.collectAsState()
    val toastMessage by viewModel.toastMessage.collectAsState()

    // Activity Result Launchers for Real File System Picking
    val singleFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.onFileSelected(context, uri)
            currentTab = MainTab.CONVERT
        }
    }

    val multipleFilesLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            if (uris.size == 1) {
                viewModel.onFileSelected(context, uris.first())
                currentTab = MainTab.CONVERT
            } else {
                viewModel.onMultipleFilesSelected(context, uris)
                currentTab = MainTab.BATCH
            }
        }
    }

    // Toast & Snackbar Handler
    LaunchedEffect(toastMessage) {
        toastMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearToast()
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            if (!isTablet) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp
                ) {
                    // CONVERT TAB
                    NavigationBarItem(
                        selected = currentTab == MainTab.CONVERT,
                        onClick = { currentTab = MainTab.CONVERT },
                        icon = {
                            Icon(
                                imageVector = if (currentTab == MainTab.CONVERT) Icons.Filled.SwapHoriz else Icons.Outlined.SwapHoriz,
                                contentDescription = StringsProvider.get("tab_convert", language)
                            )
                        },
                        label = { Text(StringsProvider.get("tab_convert", language), style = MaterialTheme.typography.labelSmall) }
                    )

                    // BATCH TAB
                    val waitingBatchCount = batchQueue.count { it.status == JobStatus.WAITING || it.status == JobStatus.CONVERTING }
                    NavigationBarItem(
                        selected = currentTab == MainTab.BATCH,
                        onClick = { currentTab = MainTab.BATCH },
                        icon = {
                            BadgedBox(
                                badge = {
                                    if (waitingBatchCount > 0) {
                                        Badge { Text("$waitingBatchCount") }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = if (currentTab == MainTab.BATCH) Icons.Filled.DynamicFeed else Icons.Outlined.DynamicFeed,
                                    contentDescription = StringsProvider.get("tab_batch", language)
                                )
                            }
                        },
                        label = { Text(StringsProvider.get("tab_batch", language), style = MaterialTheme.typography.labelSmall) }
                    )

                    // HISTORY TAB
                    NavigationBarItem(
                        selected = currentTab == MainTab.HISTORY,
                        onClick = { currentTab = MainTab.HISTORY },
                        icon = {
                            Icon(
                                imageVector = if (currentTab == MainTab.HISTORY) Icons.Filled.History else Icons.Outlined.History,
                                contentDescription = StringsProvider.get("tab_history", language)
                            )
                        },
                        label = { Text(StringsProvider.get("tab_history", language), style = MaterialTheme.typography.labelSmall) }
                    )

                    // SETTINGS TAB
                    NavigationBarItem(
                        selected = currentTab == MainTab.SETTINGS,
                        onClick = { currentTab = MainTab.SETTINGS },
                        icon = {
                            Icon(
                                imageVector = if (currentTab == MainTab.SETTINGS) Icons.Filled.Settings else Icons.Outlined.Settings,
                                contentDescription = StringsProvider.get("tab_settings", language)
                            )
                        },
                        label = { Text(StringsProvider.get("tab_settings", language), style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
        }
    ) { innerPadding ->
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // TABLET NAVIGATION RAIL
            if (isTablet) {
                NavigationRail(
                    containerColor = MaterialTheme.colorScheme.surface
                ) {
                    val waitingBatchCount = batchQueue.count { it.status == JobStatus.WAITING || it.status == JobStatus.CONVERTING }

                    NavigationRailItem(
                        selected = currentTab == MainTab.CONVERT,
                        onClick = { currentTab = MainTab.CONVERT },
                        icon = { Icon(Icons.Filled.SwapHoriz, contentDescription = null) },
                        label = { Text(StringsProvider.get("tab_convert", language)) }
                    )

                    NavigationRailItem(
                        selected = currentTab == MainTab.BATCH,
                        onClick = { currentTab = MainTab.BATCH },
                        icon = {
                            BadgedBox(badge = { if (waitingBatchCount > 0) Badge { Text("$waitingBatchCount") } }) {
                                Icon(Icons.Filled.DynamicFeed, contentDescription = null)
                            }
                        },
                        label = { Text(StringsProvider.get("tab_batch", language)) }
                    )

                    NavigationRailItem(
                        selected = currentTab == MainTab.HISTORY,
                        onClick = { currentTab = MainTab.HISTORY },
                        icon = { Icon(Icons.Filled.History, contentDescription = null) },
                        label = { Text(StringsProvider.get("tab_history", language)) }
                    )

                    NavigationRailItem(
                        selected = currentTab == MainTab.SETTINGS,
                        onClick = { currentTab = MainTab.SETTINGS },
                        icon = { Icon(Icons.Filled.Settings, contentDescription = null) },
                        label = { Text(StringsProvider.get("tab_settings", language)) }
                    )
                }
            }

            // PRIMARY CONTENT VIEW
            Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                when (currentTab) {
                    MainTab.CONVERT -> {
                        HomeScreen(
                            fileInfo = selectedFileInfo,
                            availableFormats = availableFormats,
                            selectedTarget = selectedTarget,
                            options = conversionOptions,
                            currentJob = currentJob,
                            recentHistory = filteredHistory,
                            language = language,
                            onPickSingleFile = { singleFileLauncher.launch("*/*") },
                            onPickMultipleFiles = { multipleFilesLauncher.launch("*/*") },
                            onTargetSelected = { fmt -> viewModel.selectTargetFormat(fmt) },
                            onOptionsChanged = { opt -> viewModel.updateConversionOptions(opt) },
                            onConvertClick = { viewModel.startSingleConversion(context) },
                            onCancelClick = { viewModel.cancelSingleConversion() },
                            onResetClick = { viewModel.resetSingleConversion() },
                            onShareFile = { file -> viewModel.shareFile(context, file) },
                            onOpenFile = { file -> viewModel.openFile(context, file) },
                            onNavigateToBatch = { currentTab = MainTab.BATCH },
                            onNavigateToHistory = { currentTab = MainTab.HISTORY }
                        )
                    }

                    MainTab.BATCH -> {
                        BatchScreen(
                            batchQueue = batchQueue,
                            isProcessing = isBatchProcessing,
                            language = language,
                            onAddMoreFiles = { multipleFilesLauncher.launch("*/*") },
                            onStartBatch = { viewModel.startBatchConversion() },
                            onRetryItem = { id -> viewModel.retryFailedBatchItem(id) },
                            onRemoveItem = { id -> viewModel.removeBatchItem(id) },
                            onTargetChanged = { id, fmt -> viewModel.updateBatchItemTarget(id, fmt) },
                            onClearQueue = { viewModel.clearBatchQueue() },
                            onExportAllZip = {
                                viewModel.exportBatchAsZip(context) { zipFile ->
                                    if (zipFile != null) {
                                        viewModel.showToast("Batch archived to ZIP!")
                                        viewModel.shareFile(context, zipFile)
                                    } else {
                                        viewModel.showToast("No completed files to archive")
                                    }
                                }
                            },
                            onOpenFile = { file -> viewModel.openFile(context, file) },
                            onShareFile = { file -> viewModel.shareFile(context, file) }
                        )
                    }

                    MainTab.HISTORY -> {
                        HistoryScreen(
                            historyList = filteredHistory,
                            searchQuery = searchQuery,
                            categoryFilter = categoryFilter,
                            language = language,
                            onSearchChanged = { q -> viewModel.setHistorySearchQuery(q) },
                            onFilterChanged = { f -> viewModel.setHistoryCategoryFilter(f) },
                            onDeleteItem = { id -> viewModel.deleteHistoryItem(id) },
                            onClearAll = { viewModel.clearAllHistory() },
                            onOpenFile = { file -> viewModel.openFile(context, file) },
                            onShareFile = { file -> viewModel.shareFile(context, file) }
                        )
                    }

                    MainTab.SETTINGS -> {
                        SettingsScreen(
                            currentThemeMode = themeMode,
                            currentLanguage = language,
                            cacheSizeBytes = cacheSize,
                            onThemeChanged = { mode -> viewModel.setThemeMode(mode) },
                            onLanguageChanged = { lang -> viewModel.setLanguage(lang) },
                            onClearCache = { viewModel.clearCache() }
                        )
                    }
                }
            }
        }
    }
}
