package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.engine.SafeFileNameGenerator
import com.example.localization.AppLanguage
import com.example.localization.StringsProvider
import com.example.model.FileCategory
import com.example.model.SupportedFormats
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("FileFlex", appName)
    }

    @Test
    fun `safe file name generator sanitizes and appends extension`() {
        val result = SafeFileNameGenerator.generateOutputFileName("sample:test?file.PNG", "jpg")
        assertEquals("sample_test_file.jpg", result)
    }

    @Test
    fun `supported formats return image targets`() {
        val formats = SupportedFormats.getAvailableOutputs(FileCategory.IMAGE, "png")
        assertTrue(formats.any { it.extension == "jpg" })
        assertTrue(formats.any { it.extension == "webp" })
        assertTrue(formats.any { it.extension == "pdf" })
    }

    @Test
    fun `strings provider provides localized hindi title`() {
        val title = StringsProvider.get("app_title", AppLanguage.HINDI)
        assertTrue(title.contains("FileFlex"))
    }

    @Test
    fun `developer profile strings contain Bhaskar Gautam and copyright`() {
        val devName = StringsProvider.get("developer_name", AppLanguage.ENGLISH)
        val copyright = StringsProvider.get("copyright_footer", AppLanguage.ENGLISH)
        val mobile = StringsProvider.get("developer_mobile", AppLanguage.ENGLISH)
        val email = StringsProvider.get("developer_email", AppLanguage.ENGLISH)

        assertEquals("Bhaskar Gautam", devName)
        assertTrue(copyright.contains("Bhaskar Gautam"))
        assertTrue(mobile.contains("9936293542"))
        assertEquals("Bhola.co.ghughli@gmail.com", email)
    }
}
